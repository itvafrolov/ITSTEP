<?php
    $students = ['Ivanov', 'Sidorov', 'Petrov'];

    function my_func(&$x = 100, &$y = 200)
    {
        $res = $x + $y;
        $x++;
        $y++;
        return $res;
    }
?>