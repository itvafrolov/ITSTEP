<?php
include_once "config.php";
include_once "functions.php";
?>

<?php
include_once "inc/header.php";
?>

<div id="content">
		<div id="main">
			<h1>Привет!!!</h1>	
		</div>

<?php
include_once "inc/sidebar.php";
?>

<?php
include_once "inc/footer.php";
?>