<!DOCTYPE html>
<html>
<head>
<link rel="stylesheet" href="style.css">
<title>Тест</title>
</head>
<body>
<div id="wrap">
	<div id="header">
	<h2>Тестовый сайт</h2>
	<p>Шапка сайта</p>
	</div>