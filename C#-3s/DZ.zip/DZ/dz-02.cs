using System;

namespace ConsoleApp3
{
    struct learning
    {
        int[] mathematics;
        int[] physics;
        int[] geography;
    }

    class Student
    {
        string name;
        learning estimate;
    }
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hello World!");
        }
    }
}
