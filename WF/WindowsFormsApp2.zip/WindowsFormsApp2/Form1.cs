﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp2
{
    public partial class Form1 : Form
    {
        private ContentAlignment _alignment;
        private Array _array;
        private int _position;
        public Form1()
        {
            InitializeComponent();

            _array = Enum.GetValues(typeof(ContentAlignment));
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            //tbPassword.Visible = true;
            //if (_position >= _array.Length)
            //{
            //    _position = 0;
            //}


            _position = _position % _array.Length;
            // или такая запись
            _position %= _array.Length;

            _alignment = (ContentAlignment)Enum.Parse(_alignment.GetType(), _array.GetValue(_position).ToString());

            btnImage.TextAlign = btnImage.ImageAlign = _alignment;
            btnImage.Text = _alignment.ToString();

            _position++;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            MessageBox.Show("Enter");
        }
    }
}
