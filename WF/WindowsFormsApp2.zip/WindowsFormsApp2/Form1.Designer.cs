﻿namespace WindowsFormsApp2
{
    partial class Form1
    {
        /// <summary>
        /// Обязательная переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Код, автоматически созданный конструктором форм Windows

        /// <summary>
        /// Требуемый метод для поддержки конструктора — не изменяйте 
        /// содержимое этого метода с помощью редактора кода.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblPassword = new System.Windows.Forms.Label();
            this.lbMultt = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.tbPassword = new System.Windows.Forms.TextBox();
            this.btn1 = new System.Windows.Forms.Button();
            this.tbMultiline = new System.Windows.Forms.TextBox();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.btnImage = new System.Windows.Forms.Button();
            this.btnEnter = new System.Windows.Forms.Button();
            this.btnEscape = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lblPassword
            // 
            this.lblPassword.AutoSize = true;
            this.lblPassword.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.lblPassword.Location = new System.Drawing.Point(40, 37);
            this.lblPassword.Name = "lblPassword";
            this.lblPassword.Size = new System.Drawing.Size(71, 13);
            this.lblPassword.TabIndex = 0;
            this.lblPassword.Text = "Ввод пароля";
            // 
            // lbMultt
            // 
            this.lbMultt.AutoSize = true;
            this.lbMultt.Location = new System.Drawing.Point(40, 83);
            this.lbMultt.Name = "lbMultt";
            this.lbMultt.Size = new System.Drawing.Size(118, 13);
            this.lbMultt.TabIndex = 1;
            this.lbMultt.Text = "Многострочный текст";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(40, 260);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(35, 13);
            this.label3.TabIndex = 2;
            this.label3.Text = "label3";
            // 
            // tbPassword
            // 
            this.tbPassword.Location = new System.Drawing.Point(187, 37);
            this.tbPassword.Name = "tbPassword";
            this.tbPassword.Size = new System.Drawing.Size(235, 20);
            this.tbPassword.TabIndex = 3;
            this.tbPassword.Visible = false;
            // 
            // btn1
            // 
            this.btn1.Location = new System.Drawing.Point(542, 250);
            this.btn1.Name = "btn1";
            this.btn1.Size = new System.Drawing.Size(75, 23);
            this.btn1.TabIndex = 4;
            this.btn1.Text = "button1";
            this.btn1.UseVisualStyleBackColor = true;
            this.btn1.Click += new System.EventHandler(this.button1_Click);
            // 
            // tbMultiline
            // 
            this.tbMultiline.Location = new System.Drawing.Point(187, 75);
            this.tbMultiline.Multiline = true;
            this.tbMultiline.Name = "tbMultiline";
            this.tbMultiline.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.tbMultiline.Size = new System.Drawing.Size(235, 80);
            this.tbMultiline.TabIndex = 5;
            this.tbMultiline.Text = "line1\r\nline2\r\nline3";
            // 
            // textBox1
            // 
            this.textBox1.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.textBox1.ImeMode = System.Windows.Forms.ImeMode.Off;
            this.textBox1.Location = new System.Drawing.Point(187, 252);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(235, 20);
            this.textBox1.TabIndex = 6;
            // 
            // btnImage
            // 
            this.btnImage.BackColor = System.Drawing.SystemColors.Control;
            this.btnImage.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.btnImage.FlatAppearance.BorderColor = System.Drawing.Color.Orange;
            this.btnImage.FlatAppearance.BorderSize = 3;
            this.btnImage.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Salmon;
            this.btnImage.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Lime;
            this.btnImage.Image = global::WindowsFormsApp2.Properties.Resources.SOLEIL;
            this.btnImage.Location = new System.Drawing.Point(464, 37);
            this.btnImage.Name = "btnImage";
            this.btnImage.Size = new System.Drawing.Size(338, 169);
            this.btnImage.TabIndex = 7;
            this.btnImage.Text = "button1";
            this.btnImage.UseVisualStyleBackColor = false;
            // 
            // btnEnter
            // 
            this.btnEnter.ForeColor = System.Drawing.Color.Maroon;
            this.btnEnter.Location = new System.Drawing.Point(187, 375);
            this.btnEnter.Name = "btnEnter";
            this.btnEnter.Size = new System.Drawing.Size(75, 23);
            this.btnEnter.TabIndex = 8;
            this.btnEnter.Text = "btnEnter";
            this.btnEnter.UseVisualStyleBackColor = true;
            this.btnEnter.Click += new System.EventHandler(this.button1_Click_1);
            // 
            // btnEscape
            // 
            this.btnEscape.ForeColor = System.Drawing.Color.Maroon;
            this.btnEscape.Location = new System.Drawing.Point(464, 375);
            this.btnEscape.Name = "btnEscape";
            this.btnEscape.Size = new System.Drawing.Size(75, 23);
            this.btnEscape.TabIndex = 9;
            this.btnEscape.Text = "Escape";
            this.btnEscape.UseVisualStyleBackColor = true;
            this.btnEscape.Click += new System.EventHandler(this.button2_Click);
            // 
            // Form1
            // 
            this.AcceptButton = this.btnEnter;
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.AutoScroll = true;
            this.CancelButton = this.btnEscape;
            this.CausesValidation = false;
            this.ClientSize = new System.Drawing.Size(837, 480);
            this.Controls.Add(this.btnEscape);
            this.Controls.Add(this.btnEnter);
            this.Controls.Add(this.btnImage);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.tbMultiline);
            this.Controls.Add(this.btn1);
            this.Controls.Add(this.tbPassword);
            this.Controls.Add(this.lbMultt);
            this.Controls.Add(this.lblPassword);
            this.Controls.Add(this.label3);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblPassword;
        private System.Windows.Forms.Label lbMultt;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox tbPassword;
        private System.Windows.Forms.Button btn1;
        private System.Windows.Forms.TextBox tbMultiline;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Button btnImage;
        private System.Windows.Forms.Button btnEnter;
        private System.Windows.Forms.Button btnEscape;
    }
}

