﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class MainForm : Form
    {
        private StringBuilder _builder;
        public MainForm()
        {
            InitializeComponent();
            _builder = new StringBuilder();
        }

        // Load, Activated, Diactivate, FormClosing, FormClosed

        private void MainForm_Load(object sender, EventArgs e)
        {
            //this.BackColor = Color.BlueViolet;
            BackColor = Color.FromArgb(123, 167, 83);
            _builder.AppendLine("Form_Load");
        }

        private void MainForm_Activated(object sender, EventArgs e)
        {
            _builder.AppendLine("Form_Activated");
        }

        private void MainForm_Deactivate(object sender, EventArgs e)
        {
            _builder.AppendLine("Form_Deactivate");
        }

        private void MainForm_FormClosing(object sender, FormClosingEventArgs e)
        {
            DialogResult result = MessageBox.Show("Закрыть окно?", "Закрытие окна", MessageBoxButtons.YesNo,MessageBoxIcon.Question, MessageBoxDefaultButton.Button1);
            if (result== DialogResult.No)
            {
                e.Cancel = true;
            }
        }

        private void MainForm_FormClosed(object sender, FormClosedEventArgs e)
        {
            _builder.AppendLine("Form_FormClosed");
            _builder.AppendLine(e.CloseReason.ToString());

            MessageBox.Show(_builder.ToString()); 
        }
    }
}
