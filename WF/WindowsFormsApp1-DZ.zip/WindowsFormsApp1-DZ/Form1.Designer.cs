﻿namespace WindowsFormsApp1_DZ
{
    partial class Calculator
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.button7 = new System.Windows.Forms.Button();
            this.button8 = new System.Windows.Forms.Button();
            this.button9 = new System.Windows.Forms.Button();
            this.button_divide = new System.Windows.Forms.Button();
            this.button_CE = new System.Windows.Forms.Button();
            this.buttonC = new System.Windows.Forms.Button();
            this.button_mult = new System.Windows.Forms.Button();
            this.button6 = new System.Windows.Forms.Button();
            this.button5 = new System.Windows.Forms.Button();
            this.button4 = new System.Windows.Forms.Button();
            this.button_equal = new System.Windows.Forms.Button();
            this.button_minus = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.button_plus = new System.Windows.Forms.Button();
            this.button_point = new System.Windows.Forms.Button();
            this.button0 = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // textBox1
            // 
            this.textBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox1.Location = new System.Drawing.Point(12, 12);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(340, 44);
            this.textBox1.TabIndex = 0;
            // 
            // button7
            // 
            this.button7.AutoEllipsis = true;
            this.button7.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.button7.Font = new System.Drawing.Font("Microsoft Sans Serif", 21.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.button7.Location = new System.Drawing.Point(12, 67);
            this.button7.Margin = new System.Windows.Forms.Padding(1);
            this.button7.Name = "button7";
            this.button7.Size = new System.Drawing.Size(60, 60);
            this.button7.TabIndex = 1;
            this.button7.Text = "7";
            this.button7.UseCompatibleTextRendering = true;
            this.button7.UseVisualStyleBackColor = true;
            // 
            // button8
            // 
            this.button8.AutoEllipsis = true;
            this.button8.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.button8.Font = new System.Drawing.Font("Microsoft Sans Serif", 21.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.button8.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.button8.Location = new System.Drawing.Point(82, 67);
            this.button8.Margin = new System.Windows.Forms.Padding(1);
            this.button8.Name = "button8";
            this.button8.Size = new System.Drawing.Size(60, 60);
            this.button8.TabIndex = 2;
            this.button8.Text = "8";
            this.button8.UseCompatibleTextRendering = true;
            this.button8.UseVisualStyleBackColor = true;
            // 
            // button9
            // 
            this.button9.AutoEllipsis = true;
            this.button9.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.button9.Font = new System.Drawing.Font("Microsoft Sans Serif", 21.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.button9.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.button9.Location = new System.Drawing.Point(152, 67);
            this.button9.Margin = new System.Windows.Forms.Padding(1);
            this.button9.Name = "button9";
            this.button9.Size = new System.Drawing.Size(60, 60);
            this.button9.TabIndex = 3;
            this.button9.Text = "9";
            this.button9.UseCompatibleTextRendering = true;
            this.button9.UseVisualStyleBackColor = true;
            // 
            // button_divide
            // 
            this.button_divide.AutoEllipsis = true;
            this.button_divide.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.button_divide.Font = new System.Drawing.Font("Microsoft Sans Serif", 21.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.button_divide.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.button_divide.Location = new System.Drawing.Point(222, 67);
            this.button_divide.Margin = new System.Windows.Forms.Padding(1);
            this.button_divide.Name = "button_divide";
            this.button_divide.Size = new System.Drawing.Size(60, 60);
            this.button_divide.TabIndex = 4;
            this.button_divide.Text = "/";
            this.button_divide.UseCompatibleTextRendering = true;
            this.button_divide.UseVisualStyleBackColor = true;
            // 
            // button_CE
            // 
            this.button_CE.AutoEllipsis = true;
            this.button_CE.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.button_CE.Font = new System.Drawing.Font("Microsoft Sans Serif", 21.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.button_CE.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.button_CE.Location = new System.Drawing.Point(292, 67);
            this.button_CE.Margin = new System.Windows.Forms.Padding(1);
            this.button_CE.Name = "button_CE";
            this.button_CE.Size = new System.Drawing.Size(60, 60);
            this.button_CE.TabIndex = 5;
            this.button_CE.Text = "CE";
            this.button_CE.UseCompatibleTextRendering = true;
            this.button_CE.UseVisualStyleBackColor = true;
            // 
            // buttonC
            // 
            this.buttonC.AutoEllipsis = true;
            this.buttonC.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.buttonC.Font = new System.Drawing.Font("Microsoft Sans Serif", 21.75F);
            this.buttonC.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.buttonC.Location = new System.Drawing.Point(292, 138);
            this.buttonC.Margin = new System.Windows.Forms.Padding(1);
            this.buttonC.Name = "buttonC";
            this.buttonC.Size = new System.Drawing.Size(60, 60);
            this.buttonC.TabIndex = 10;
            this.buttonC.Text = "C";
            this.buttonC.UseCompatibleTextRendering = true;
            this.buttonC.UseVisualStyleBackColor = true;
            // 
            // button_mult
            // 
            this.button_mult.AutoEllipsis = true;
            this.button_mult.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.button_mult.Font = new System.Drawing.Font("Microsoft Sans Serif", 21.75F);
            this.button_mult.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.button_mult.Location = new System.Drawing.Point(222, 138);
            this.button_mult.Margin = new System.Windows.Forms.Padding(1);
            this.button_mult.Name = "button_mult";
            this.button_mult.Size = new System.Drawing.Size(60, 60);
            this.button_mult.TabIndex = 9;
            this.button_mult.Text = "*";
            this.button_mult.UseCompatibleTextRendering = true;
            this.button_mult.UseVisualStyleBackColor = true;
            // 
            // button6
            // 
            this.button6.AutoEllipsis = true;
            this.button6.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.button6.Font = new System.Drawing.Font("Microsoft Sans Serif", 21.75F);
            this.button6.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.button6.Location = new System.Drawing.Point(152, 138);
            this.button6.Margin = new System.Windows.Forms.Padding(1);
            this.button6.Name = "button6";
            this.button6.Size = new System.Drawing.Size(60, 60);
            this.button6.TabIndex = 8;
            this.button6.Text = "6";
            this.button6.UseCompatibleTextRendering = true;
            this.button6.UseVisualStyleBackColor = true;
            // 
            // button5
            // 
            this.button5.AutoEllipsis = true;
            this.button5.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.button5.Font = new System.Drawing.Font("Microsoft Sans Serif", 21.75F);
            this.button5.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.button5.Location = new System.Drawing.Point(82, 138);
            this.button5.Margin = new System.Windows.Forms.Padding(1);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(60, 60);
            this.button5.TabIndex = 7;
            this.button5.Text = "5";
            this.button5.UseCompatibleTextRendering = true;
            this.button5.UseVisualStyleBackColor = true;
            // 
            // button4
            // 
            this.button4.AutoEllipsis = true;
            this.button4.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.button4.Font = new System.Drawing.Font("Microsoft Sans Serif", 21.75F);
            this.button4.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.button4.Location = new System.Drawing.Point(12, 138);
            this.button4.Margin = new System.Windows.Forms.Padding(1);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(60, 60);
            this.button4.TabIndex = 6;
            this.button4.Text = "4";
            this.button4.UseCompatibleTextRendering = true;
            this.button4.UseVisualStyleBackColor = true;
            // 
            // button_equal
            // 
            this.button_equal.AutoEllipsis = true;
            this.button_equal.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.button_equal.Font = new System.Drawing.Font("Microsoft Sans Serif", 21.75F);
            this.button_equal.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.button_equal.Location = new System.Drawing.Point(292, 210);
            this.button_equal.Margin = new System.Windows.Forms.Padding(1);
            this.button_equal.Name = "button_equal";
            this.button_equal.Size = new System.Drawing.Size(60, 131);
            this.button_equal.TabIndex = 15;
            this.button_equal.Text = "=";
            this.button_equal.UseCompatibleTextRendering = true;
            this.button_equal.UseVisualStyleBackColor = true;
            this.button_equal.Click += new System.EventHandler(this.button1_Click);
            // 
            // button_minus
            // 
            this.button_minus.AutoEllipsis = true;
            this.button_minus.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.button_minus.Font = new System.Drawing.Font("Microsoft Sans Serif", 21.75F);
            this.button_minus.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.button_minus.Location = new System.Drawing.Point(222, 210);
            this.button_minus.Margin = new System.Windows.Forms.Padding(1);
            this.button_minus.Name = "button_minus";
            this.button_minus.Size = new System.Drawing.Size(60, 60);
            this.button_minus.TabIndex = 14;
            this.button_minus.Text = "-";
            this.button_minus.UseCompatibleTextRendering = true;
            this.button_minus.UseVisualStyleBackColor = true;
            // 
            // button3
            // 
            this.button3.AutoEllipsis = true;
            this.button3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.button3.Font = new System.Drawing.Font("Microsoft Sans Serif", 21.75F);
            this.button3.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.button3.Location = new System.Drawing.Point(152, 210);
            this.button3.Margin = new System.Windows.Forms.Padding(1);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(60, 60);
            this.button3.TabIndex = 13;
            this.button3.Text = "3";
            this.button3.UseCompatibleTextRendering = true;
            this.button3.UseVisualStyleBackColor = true;
            // 
            // button2
            // 
            this.button2.AutoEllipsis = true;
            this.button2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.button2.Font = new System.Drawing.Font("Microsoft Sans Serif", 21.75F);
            this.button2.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.button2.Location = new System.Drawing.Point(82, 210);
            this.button2.Margin = new System.Windows.Forms.Padding(1);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(60, 60);
            this.button2.TabIndex = 12;
            this.button2.Text = "2";
            this.button2.UseCompatibleTextRendering = true;
            this.button2.UseVisualStyleBackColor = true;
            // 
            // button1
            // 
            this.button1.AutoEllipsis = true;
            this.button1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.button1.Font = new System.Drawing.Font("Microsoft Sans Serif", 21.75F);
            this.button1.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.button1.Location = new System.Drawing.Point(12, 210);
            this.button1.Margin = new System.Windows.Forms.Padding(1);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(60, 60);
            this.button1.TabIndex = 11;
            this.button1.Text = "1";
            this.button1.UseCompatibleTextRendering = true;
            this.button1.UseVisualStyleBackColor = true;
            // 
            // button_plus
            // 
            this.button_plus.AutoEllipsis = true;
            this.button_plus.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.button_plus.Font = new System.Drawing.Font("Microsoft Sans Serif", 21.75F);
            this.button_plus.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.button_plus.Location = new System.Drawing.Point(222, 281);
            this.button_plus.Margin = new System.Windows.Forms.Padding(1);
            this.button_plus.Name = "button_plus";
            this.button_plus.Size = new System.Drawing.Size(60, 60);
            this.button_plus.TabIndex = 19;
            this.button_plus.Text = "+";
            this.button_plus.UseCompatibleTextRendering = true;
            this.button_plus.UseVisualStyleBackColor = true;
            // 
            // button_point
            // 
            this.button_point.AutoEllipsis = true;
            this.button_point.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.button_point.Font = new System.Drawing.Font("Microsoft Sans Serif", 21.75F);
            this.button_point.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.button_point.Location = new System.Drawing.Point(152, 281);
            this.button_point.Margin = new System.Windows.Forms.Padding(1);
            this.button_point.Name = "button_point";
            this.button_point.Size = new System.Drawing.Size(60, 60);
            this.button_point.TabIndex = 18;
            this.button_point.Text = ".";
            this.button_point.UseCompatibleTextRendering = true;
            this.button_point.UseVisualStyleBackColor = true;
            // 
            // button0
            // 
            this.button0.AutoEllipsis = true;
            this.button0.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.button0.Font = new System.Drawing.Font("Microsoft Sans Serif", 21.75F);
            this.button0.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.button0.Location = new System.Drawing.Point(12, 281);
            this.button0.Margin = new System.Windows.Forms.Padding(1);
            this.button0.Name = "button0";
            this.button0.Size = new System.Drawing.Size(130, 60);
            this.button0.TabIndex = 16;
            this.button0.Text = "0";
            this.button0.UseCompatibleTextRendering = true;
            this.button0.UseVisualStyleBackColor = true;
            // 
            // Calculator
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(365, 354);
            this.Controls.Add(this.button_plus);
            this.Controls.Add(this.button_point);
            this.Controls.Add(this.button0);
            this.Controls.Add(this.button_equal);
            this.Controls.Add(this.button_minus);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.buttonC);
            this.Controls.Add(this.button_mult);
            this.Controls.Add(this.button6);
            this.Controls.Add(this.button5);
            this.Controls.Add(this.button4);
            this.Controls.Add(this.button_CE);
            this.Controls.Add(this.button_divide);
            this.Controls.Add(this.button9);
            this.Controls.Add(this.button8);
            this.Controls.Add(this.button7);
            this.Controls.Add(this.textBox1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.MaximizeBox = false;
            this.Name = "Calculator";
            this.Text = "Calculator";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Button button7;
        private System.Windows.Forms.Button button8;
        private System.Windows.Forms.Button button9;
        private System.Windows.Forms.Button button_divide;
        private System.Windows.Forms.Button button_CE;
        private System.Windows.Forms.Button buttonC;
        private System.Windows.Forms.Button button_mult;
        private System.Windows.Forms.Button button6;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Button button_equal;
        private System.Windows.Forms.Button button_minus;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button_plus;
        private System.Windows.Forms.Button button_point;
        private System.Windows.Forms.Button button0;
    }
}

