﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1_DZ
{
    public partial class Calculator : Form
    {
        public
        string str = null;
        string strVal= null;
        double result;
        string endOperator = null;
        public Calculator()
        {
            InitializeComponent();
        }
        private void button0_Click(object sender, EventArgs e)
        {
            if (str != null)
            {
                str = str + "0";
                strVal = strVal + "0";
                textBox1.Text = str;
            }
        }
        private void button1_Click(object sender, EventArgs e)
        {           
                str = str + "1";
                strVal = strVal + "1";
                textBox1.Text = str;         
        }

        private void button2_Click(object sender, EventArgs e)
        {
                str = str + "2";
                strVal = strVal + "2";
                textBox1.Text = str;
        }

        private void button3_Click(object sender, EventArgs e)
        {
            str = str + "3";
            strVal = strVal + "3";
            textBox1.Text = str;
        }

        private void button4_Click(object sender, EventArgs e)
        {
            str = str + "4";
            strVal = strVal + "4";
            textBox1.Text = str;
        }

        private void button5_Click(object sender, EventArgs e)
        {
            str = str + "5";
            strVal = strVal + "5";
            textBox1.Text = str;
        }

        private void button6_Click(object sender, EventArgs e)
        {
            str = str + "6";
            strVal = strVal + "6";
            textBox1.Text = str;
        }

        private void button7_Click(object sender, EventArgs e)
        {
            str = str + "7";
            strVal = strVal + "7";
            textBox1.Text = str;
        }

        private void button8_Click(object sender, EventArgs e)
        {
            str = str + "8";
            strVal = strVal + "8";
            textBox1.Text = str;
        }

        private void button9_Click(object sender, EventArgs e)
        {
            str = str + "9";
            strVal = strVal + "9";
            textBox1.Text = str;
        }
        private void button_point_Click(object sender, EventArgs e)
        {
            str = str + ".";
            strVal = strVal + ".";
            textBox1.Text = str;
        }
        private void button_CE_Click(object sender, EventArgs e)
        {
            str = null;
            strVal = null;
            textBox1.Text = str;
        }

        private void buttonC_Click(object sender, EventArgs e)
        {
            str = null;
            strVal = null;
            textBox1.Text = str;
        }

        private void button_plus_Click(object sender, EventArgs e)
        {
            if (strVal != null)
            {
                if (endOperator==null)
                {
                    result = double.Parse(strVal);                
                }
                else
                {
                    result = result_Val(strVal, endOperator);
                }                
                str = str + "+";
                strVal = null;
                textBox1.Text = str;
                endOperator = "+";
            }
        }
        private double result_Val(string strVal, string oper)
        {  
            switch (endOperator)
            {
               case "+":
                    result = result + double.Parse(strVal);
                    break;
                case "-":
                    result = result - double.Parse(strVal);
                    break;
                case "/":
                    result = result / double.Parse(strVal);
                    break;
                case "*":
                    result = result * double.Parse(strVal);
                    break;
            }
            return result;
        }
      private void button_Val(object sender, EventArgs e)
        {
            str = null;                         
            textBox1.Text = result_Val(strVal, endOperator).ToString();
            strVal = null;
            result = 0;
            endOperator = null;
        }

        private void button_minus_Click(object sender, EventArgs e)
        {
            if (strVal != null)
            {
                if (endOperator == null)
                {
                    result = double.Parse(strVal);
                }
                else
                {
                    result = result_Val(strVal, endOperator);
                }
                str = str + "-";
                strVal = null;
                textBox1.Text = str;
                endOperator = "-";
            }
        }

        private void button_mult_Click(object sender, EventArgs e)
        {
            if (strVal != null)
            {
                if (endOperator == null)
                {
                    result = double.Parse(strVal);
                }
                else
                {
                    result = result_Val(strVal, endOperator);
                }
                str = str + "*";
                strVal = null;
                textBox1.Text = str;
                endOperator = "*";
            }
        }

        private void button_divide_Click(object sender, EventArgs e)
        {
            if (strVal != null)
            {
                if (endOperator == null)
                {
                    result = double.Parse(strVal);
                }
                else
                {
                    result = result_Val(strVal, endOperator);
                }
                str = str + "/";
                strVal = null;
                textBox1.Text = str;
                endOperator = "/";
            }
        }
    }
}
