﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace WpfApp1
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
            //WindowStartupLocation = WindowStartupLocation.CenterScreen;
        }

        

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            Window WindowProba1 = new Window();
            WindowProba1.Title = "Окно запущеное другим способом!";
            WindowProba1.Height = 150;
            WindowProba1.Width = 500;
            WindowProba1.WindowStartupLocation = WindowStartupLocation.CenterScreen;
            WindowProba1.Show();
        }

        private void Button2_Click(object sender, RoutedEventArgs e)
        {
            MessageBox.Show("НЕ ПОНЯЛ ЗАДАНИЕ!!!");
        }
    }  
    
}


