﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;



namespace Project9
{
	class MyWPFApp : Application
	{
		[STAThread]
		static void Main()
		{

			MyWPFApp app = new MyWPFApp();
			app.Startup += AppStartUp;
			app.Exit += AppExit;
			
			app.Run();

		}
		static void AppExit(object sender, ExitEventArgs e)
		{
			MessageBox.Show("Не нашел как прикрутить кнопку!!!");
		}

		static void AppStartUp(object sender, StartupEventArgs e)
		{
			Window mainWindow = new Window();
			mainWindow.Title = "Окно сгенерированное вручную";
			mainWindow.Height = 600;
			mainWindow.Width = 900;
			mainWindow.WindowStartupLocation = WindowStartupLocation.CenterScreen;
			Button but1 = new Button();
			but1.Name = "btn1";
			but1.Content = "Нажми меня!";
			but1.Width = 100;
			but1.Height = 20;
			; 
			

			mainWindow.Show();
		}

	}

}
